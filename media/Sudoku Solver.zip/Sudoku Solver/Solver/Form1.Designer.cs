﻿namespace SudokuSolver
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Box1Cell1tb = new System.Windows.Forms.TextBox();
            this.Box1Cell2tb = new System.Windows.Forms.TextBox();
            this.Box1Cell3tb = new System.Windows.Forms.TextBox();
            this.Box1Cell4tb = new System.Windows.Forms.TextBox();
            this.Box1Cell5tb = new System.Windows.Forms.TextBox();
            this.Box1Cell6tb = new System.Windows.Forms.TextBox();
            this.Box1Cell7tb = new System.Windows.Forms.TextBox();
            this.Box1Cell8tb = new System.Windows.Forms.TextBox();
            this.Box1Cell9tb = new System.Windows.Forms.TextBox();
            this.Box2Cell9tb = new System.Windows.Forms.TextBox();
            this.Box2Cell8tb = new System.Windows.Forms.TextBox();
            this.Box2Cell7tb = new System.Windows.Forms.TextBox();
            this.Box2Cell6tb = new System.Windows.Forms.TextBox();
            this.Box2Cell5tb = new System.Windows.Forms.TextBox();
            this.Box2Cell4tb = new System.Windows.Forms.TextBox();
            this.Box2Cell3tb = new System.Windows.Forms.TextBox();
            this.Box2Cell2tb = new System.Windows.Forms.TextBox();
            this.Box2Cell1tb = new System.Windows.Forms.TextBox();
            this.Box3Cell1tb = new System.Windows.Forms.TextBox();
            this.Box3Cell2tb = new System.Windows.Forms.TextBox();
            this.Box3Cell3tb = new System.Windows.Forms.TextBox();
            this.Box3Cell4tb = new System.Windows.Forms.TextBox();
            this.Box3Cell5tb = new System.Windows.Forms.TextBox();
            this.Box3Cell6tb = new System.Windows.Forms.TextBox();
            this.Box3Cell7tb = new System.Windows.Forms.TextBox();
            this.Box3Cell8tb = new System.Windows.Forms.TextBox();
            this.Box3Cell9tb = new System.Windows.Forms.TextBox();
            this.Box4Cell1tb = new System.Windows.Forms.TextBox();
            this.Box4Cell3tb = new System.Windows.Forms.TextBox();
            this.Box4Cell4tb = new System.Windows.Forms.TextBox();
            this.Box4Cell5tb = new System.Windows.Forms.TextBox();
            this.Box4Cell6tb = new System.Windows.Forms.TextBox();
            this.Box4Cell7tb = new System.Windows.Forms.TextBox();
            this.Box4Cell8tb = new System.Windows.Forms.TextBox();
            this.Box4Cell9tb = new System.Windows.Forms.TextBox();
            this.Box5Cell9tb = new System.Windows.Forms.TextBox();
            this.Box5Cell8tb = new System.Windows.Forms.TextBox();
            this.Box5Cell7tb = new System.Windows.Forms.TextBox();
            this.Box5Cell6tb = new System.Windows.Forms.TextBox();
            this.Box4Cell2tb = new System.Windows.Forms.TextBox();
            this.Box5Cell5tb = new System.Windows.Forms.TextBox();
            this.Box5Cell3tb = new System.Windows.Forms.TextBox();
            this.Box5Cell2tb = new System.Windows.Forms.TextBox();
            this.Box5Cell1tb = new System.Windows.Forms.TextBox();
            this.Box6Cell1tb = new System.Windows.Forms.TextBox();
            this.Box6Cell2tb = new System.Windows.Forms.TextBox();
            this.Box6Cell3tb = new System.Windows.Forms.TextBox();
            this.Box6Cell4tb = new System.Windows.Forms.TextBox();
            this.Box6Cell5tb = new System.Windows.Forms.TextBox();
            this.Box6Cell6tb = new System.Windows.Forms.TextBox();
            this.Box6Cell7tb = new System.Windows.Forms.TextBox();
            this.Box6Cell8tb = new System.Windows.Forms.TextBox();
            this.Box5Cell4tb = new System.Windows.Forms.TextBox();
            this.Box6Cell9tb = new System.Windows.Forms.TextBox();
            this.Box7Cell1tb = new System.Windows.Forms.TextBox();
            this.Box7Cell4tb = new System.Windows.Forms.TextBox();
            this.Box7Cell5tb = new System.Windows.Forms.TextBox();
            this.Box7Cell6tb = new System.Windows.Forms.TextBox();
            this.Box7Cell7tb = new System.Windows.Forms.TextBox();
            this.Box7Cell8tb = new System.Windows.Forms.TextBox();
            this.Box7Cell9tb = new System.Windows.Forms.TextBox();
            this.Box8Cell9tb = new System.Windows.Forms.TextBox();
            this.Box8Cell8tb = new System.Windows.Forms.TextBox();
            this.Box8Cell7tb = new System.Windows.Forms.TextBox();
            this.Box8Cell6tb = new System.Windows.Forms.TextBox();
            this.Box7Cell2tb = new System.Windows.Forms.TextBox();
            this.Box7Cell3tb = new System.Windows.Forms.TextBox();
            this.Box8Cell5tb = new System.Windows.Forms.TextBox();
            this.Box8Cell2tb = new System.Windows.Forms.TextBox();
            this.Box8Cell1tb = new System.Windows.Forms.TextBox();
            this.Box9Cell1tb = new System.Windows.Forms.TextBox();
            this.Box9Cell2tb = new System.Windows.Forms.TextBox();
            this.Box9Cell3tb = new System.Windows.Forms.TextBox();
            this.Box9Cell4tb = new System.Windows.Forms.TextBox();
            this.Box9Cell5tb = new System.Windows.Forms.TextBox();
            this.Box9Cell6tb = new System.Windows.Forms.TextBox();
            this.Box9Cell7tb = new System.Windows.Forms.TextBox();
            this.Box9Cell8tb = new System.Windows.Forms.TextBox();
            this.Box8Cell4tb = new System.Windows.Forms.TextBox();
            this.Box8Cell3tb = new System.Windows.Forms.TextBox();
            this.Box9Cell9tb = new System.Windows.Forms.TextBox();
            this.SolveBtn = new System.Windows.Forms.Button();
            this.debugLabel = new System.Windows.Forms.Label();
            this.ClearBtn = new System.Windows.Forms.Button();
            this.ErrorLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Box1Cell1tb
            // 
            this.Box1Cell1tb.Location = new System.Drawing.Point(40, 40);
            this.Box1Cell1tb.Name = "Box1Cell1tb";
            this.Box1Cell1tb.Size = new System.Drawing.Size(23, 23);
            this.Box1Cell1tb.TabIndex = 0;
            // 
            // Box1Cell2tb
            // 
            this.Box1Cell2tb.Location = new System.Drawing.Point(69, 40);
            this.Box1Cell2tb.Name = "Box1Cell2tb";
            this.Box1Cell2tb.Size = new System.Drawing.Size(23, 23);
            this.Box1Cell2tb.TabIndex = 0;
            // 
            // Box1Cell3tb
            // 
            this.Box1Cell3tb.Location = new System.Drawing.Point(98, 40);
            this.Box1Cell3tb.Name = "Box1Cell3tb";
            this.Box1Cell3tb.Size = new System.Drawing.Size(23, 23);
            this.Box1Cell3tb.TabIndex = 0;
            // 
            // Box1Cell4tb
            // 
            this.Box1Cell4tb.Location = new System.Drawing.Point(40, 69);
            this.Box1Cell4tb.Name = "Box1Cell4tb";
            this.Box1Cell4tb.Size = new System.Drawing.Size(23, 23);
            this.Box1Cell4tb.TabIndex = 0;
            // 
            // Box1Cell5tb
            // 
            this.Box1Cell5tb.Location = new System.Drawing.Point(69, 69);
            this.Box1Cell5tb.Name = "Box1Cell5tb";
            this.Box1Cell5tb.Size = new System.Drawing.Size(23, 23);
            this.Box1Cell5tb.TabIndex = 0;
            // 
            // Box1Cell6tb
            // 
            this.Box1Cell6tb.Location = new System.Drawing.Point(98, 69);
            this.Box1Cell6tb.Name = "Box1Cell6tb";
            this.Box1Cell6tb.Size = new System.Drawing.Size(23, 23);
            this.Box1Cell6tb.TabIndex = 0;
            // 
            // Box1Cell7tb
            // 
            this.Box1Cell7tb.Location = new System.Drawing.Point(40, 98);
            this.Box1Cell7tb.Name = "Box1Cell7tb";
            this.Box1Cell7tb.Size = new System.Drawing.Size(23, 23);
            this.Box1Cell7tb.TabIndex = 0;
            // 
            // Box1Cell8tb
            // 
            this.Box1Cell8tb.Location = new System.Drawing.Point(69, 98);
            this.Box1Cell8tb.Name = "Box1Cell8tb";
            this.Box1Cell8tb.Size = new System.Drawing.Size(23, 23);
            this.Box1Cell8tb.TabIndex = 0;
            // 
            // Box1Cell9tb
            // 
            this.Box1Cell9tb.Location = new System.Drawing.Point(98, 98);
            this.Box1Cell9tb.Name = "Box1Cell9tb";
            this.Box1Cell9tb.Size = new System.Drawing.Size(23, 23);
            this.Box1Cell9tb.TabIndex = 0;
            // 
            // Box2Cell9tb
            // 
            this.Box2Cell9tb.Location = new System.Drawing.Point(190, 98);
            this.Box2Cell9tb.Name = "Box2Cell9tb";
            this.Box2Cell9tb.Size = new System.Drawing.Size(23, 23);
            this.Box2Cell9tb.TabIndex = 0;
            // 
            // Box2Cell8tb
            // 
            this.Box2Cell8tb.Location = new System.Drawing.Point(161, 98);
            this.Box2Cell8tb.Name = "Box2Cell8tb";
            this.Box2Cell8tb.Size = new System.Drawing.Size(23, 23);
            this.Box2Cell8tb.TabIndex = 0;
            // 
            // Box2Cell7tb
            // 
            this.Box2Cell7tb.Location = new System.Drawing.Point(132, 98);
            this.Box2Cell7tb.Name = "Box2Cell7tb";
            this.Box2Cell7tb.Size = new System.Drawing.Size(23, 23);
            this.Box2Cell7tb.TabIndex = 0;
            // 
            // Box2Cell6tb
            // 
            this.Box2Cell6tb.Location = new System.Drawing.Point(190, 69);
            this.Box2Cell6tb.Name = "Box2Cell6tb";
            this.Box2Cell6tb.Size = new System.Drawing.Size(23, 23);
            this.Box2Cell6tb.TabIndex = 0;
            // 
            // Box2Cell5tb
            // 
            this.Box2Cell5tb.Location = new System.Drawing.Point(161, 69);
            this.Box2Cell5tb.Name = "Box2Cell5tb";
            this.Box2Cell5tb.Size = new System.Drawing.Size(23, 23);
            this.Box2Cell5tb.TabIndex = 0;
            // 
            // Box2Cell4tb
            // 
            this.Box2Cell4tb.Location = new System.Drawing.Point(132, 69);
            this.Box2Cell4tb.Name = "Box2Cell4tb";
            this.Box2Cell4tb.Size = new System.Drawing.Size(23, 23);
            this.Box2Cell4tb.TabIndex = 0;
            // 
            // Box2Cell3tb
            // 
            this.Box2Cell3tb.Location = new System.Drawing.Point(190, 40);
            this.Box2Cell3tb.Name = "Box2Cell3tb";
            this.Box2Cell3tb.Size = new System.Drawing.Size(23, 23);
            this.Box2Cell3tb.TabIndex = 0;
            // 
            // Box2Cell2tb
            // 
            this.Box2Cell2tb.Location = new System.Drawing.Point(161, 40);
            this.Box2Cell2tb.Name = "Box2Cell2tb";
            this.Box2Cell2tb.Size = new System.Drawing.Size(23, 23);
            this.Box2Cell2tb.TabIndex = 0;
            // 
            // Box2Cell1tb
            // 
            this.Box2Cell1tb.Location = new System.Drawing.Point(132, 40);
            this.Box2Cell1tb.Name = "Box2Cell1tb";
            this.Box2Cell1tb.Size = new System.Drawing.Size(23, 23);
            this.Box2Cell1tb.TabIndex = 0;
            // 
            // Box3Cell1tb
            // 
            this.Box3Cell1tb.Location = new System.Drawing.Point(224, 40);
            this.Box3Cell1tb.Name = "Box3Cell1tb";
            this.Box3Cell1tb.Size = new System.Drawing.Size(23, 23);
            this.Box3Cell1tb.TabIndex = 0;
            // 
            // Box3Cell2tb
            // 
            this.Box3Cell2tb.Location = new System.Drawing.Point(253, 40);
            this.Box3Cell2tb.Name = "Box3Cell2tb";
            this.Box3Cell2tb.Size = new System.Drawing.Size(23, 23);
            this.Box3Cell2tb.TabIndex = 0;
            // 
            // Box3Cell3tb
            // 
            this.Box3Cell3tb.Location = new System.Drawing.Point(282, 40);
            this.Box3Cell3tb.Name = "Box3Cell3tb";
            this.Box3Cell3tb.Size = new System.Drawing.Size(23, 23);
            this.Box3Cell3tb.TabIndex = 0;
            // 
            // Box3Cell4tb
            // 
            this.Box3Cell4tb.Location = new System.Drawing.Point(224, 69);
            this.Box3Cell4tb.Name = "Box3Cell4tb";
            this.Box3Cell4tb.Size = new System.Drawing.Size(23, 23);
            this.Box3Cell4tb.TabIndex = 0;
            // 
            // Box3Cell5tb
            // 
            this.Box3Cell5tb.Location = new System.Drawing.Point(253, 69);
            this.Box3Cell5tb.Name = "Box3Cell5tb";
            this.Box3Cell5tb.Size = new System.Drawing.Size(23, 23);
            this.Box3Cell5tb.TabIndex = 0;
            // 
            // Box3Cell6tb
            // 
            this.Box3Cell6tb.Location = new System.Drawing.Point(282, 69);
            this.Box3Cell6tb.Name = "Box3Cell6tb";
            this.Box3Cell6tb.Size = new System.Drawing.Size(23, 23);
            this.Box3Cell6tb.TabIndex = 0;
            // 
            // Box3Cell7tb
            // 
            this.Box3Cell7tb.Location = new System.Drawing.Point(224, 98);
            this.Box3Cell7tb.Name = "Box3Cell7tb";
            this.Box3Cell7tb.Size = new System.Drawing.Size(23, 23);
            this.Box3Cell7tb.TabIndex = 0;
            // 
            // Box3Cell8tb
            // 
            this.Box3Cell8tb.Location = new System.Drawing.Point(253, 98);
            this.Box3Cell8tb.Name = "Box3Cell8tb";
            this.Box3Cell8tb.Size = new System.Drawing.Size(23, 23);
            this.Box3Cell8tb.TabIndex = 0;
            // 
            // Box3Cell9tb
            // 
            this.Box3Cell9tb.Location = new System.Drawing.Point(282, 98);
            this.Box3Cell9tb.Name = "Box3Cell9tb";
            this.Box3Cell9tb.Size = new System.Drawing.Size(23, 23);
            this.Box3Cell9tb.TabIndex = 0;
            // 
            // Box4Cell1tb
            // 
            this.Box4Cell1tb.Location = new System.Drawing.Point(40, 132);
            this.Box4Cell1tb.Name = "Box4Cell1tb";
            this.Box4Cell1tb.Size = new System.Drawing.Size(23, 23);
            this.Box4Cell1tb.TabIndex = 0;
            // 
            // Box4Cell3tb
            // 
            this.Box4Cell3tb.Location = new System.Drawing.Point(98, 132);
            this.Box4Cell3tb.Name = "Box4Cell3tb";
            this.Box4Cell3tb.Size = new System.Drawing.Size(23, 23);
            this.Box4Cell3tb.TabIndex = 0;
            // 
            // Box4Cell4tb
            // 
            this.Box4Cell4tb.Location = new System.Drawing.Point(40, 161);
            this.Box4Cell4tb.Name = "Box4Cell4tb";
            this.Box4Cell4tb.Size = new System.Drawing.Size(23, 23);
            this.Box4Cell4tb.TabIndex = 0;
            // 
            // Box4Cell5tb
            // 
            this.Box4Cell5tb.Location = new System.Drawing.Point(69, 161);
            this.Box4Cell5tb.Name = "Box4Cell5tb";
            this.Box4Cell5tb.Size = new System.Drawing.Size(23, 23);
            this.Box4Cell5tb.TabIndex = 0;
            // 
            // Box4Cell6tb
            // 
            this.Box4Cell6tb.Location = new System.Drawing.Point(98, 161);
            this.Box4Cell6tb.Name = "Box4Cell6tb";
            this.Box4Cell6tb.Size = new System.Drawing.Size(23, 23);
            this.Box4Cell6tb.TabIndex = 0;
            // 
            // Box4Cell7tb
            // 
            this.Box4Cell7tb.Location = new System.Drawing.Point(40, 190);
            this.Box4Cell7tb.Name = "Box4Cell7tb";
            this.Box4Cell7tb.Size = new System.Drawing.Size(23, 23);
            this.Box4Cell7tb.TabIndex = 0;
            // 
            // Box4Cell8tb
            // 
            this.Box4Cell8tb.Location = new System.Drawing.Point(69, 190);
            this.Box4Cell8tb.Name = "Box4Cell8tb";
            this.Box4Cell8tb.Size = new System.Drawing.Size(23, 23);
            this.Box4Cell8tb.TabIndex = 0;
            // 
            // Box4Cell9tb
            // 
            this.Box4Cell9tb.Location = new System.Drawing.Point(98, 190);
            this.Box4Cell9tb.Name = "Box4Cell9tb";
            this.Box4Cell9tb.Size = new System.Drawing.Size(23, 23);
            this.Box4Cell9tb.TabIndex = 0;
            // 
            // Box5Cell9tb
            // 
            this.Box5Cell9tb.Location = new System.Drawing.Point(190, 190);
            this.Box5Cell9tb.Name = "Box5Cell9tb";
            this.Box5Cell9tb.Size = new System.Drawing.Size(23, 23);
            this.Box5Cell9tb.TabIndex = 0;
            // 
            // Box5Cell8tb
            // 
            this.Box5Cell8tb.Location = new System.Drawing.Point(161, 190);
            this.Box5Cell8tb.Name = "Box5Cell8tb";
            this.Box5Cell8tb.Size = new System.Drawing.Size(23, 23);
            this.Box5Cell8tb.TabIndex = 0;
            // 
            // Box5Cell7tb
            // 
            this.Box5Cell7tb.Location = new System.Drawing.Point(132, 190);
            this.Box5Cell7tb.Name = "Box5Cell7tb";
            this.Box5Cell7tb.Size = new System.Drawing.Size(23, 23);
            this.Box5Cell7tb.TabIndex = 0;
            // 
            // Box5Cell6tb
            // 
            this.Box5Cell6tb.Location = new System.Drawing.Point(190, 161);
            this.Box5Cell6tb.Name = "Box5Cell6tb";
            this.Box5Cell6tb.Size = new System.Drawing.Size(23, 23);
            this.Box5Cell6tb.TabIndex = 0;
            // 
            // Box4Cell2tb
            // 
            this.Box4Cell2tb.Location = new System.Drawing.Point(69, 132);
            this.Box4Cell2tb.Name = "Box4Cell2tb";
            this.Box4Cell2tb.Size = new System.Drawing.Size(23, 23);
            this.Box4Cell2tb.TabIndex = 0;
            // 
            // Box5Cell5tb
            // 
            this.Box5Cell5tb.Location = new System.Drawing.Point(161, 161);
            this.Box5Cell5tb.Name = "Box5Cell5tb";
            this.Box5Cell5tb.Size = new System.Drawing.Size(23, 23);
            this.Box5Cell5tb.TabIndex = 0;
            // 
            // Box5Cell3tb
            // 
            this.Box5Cell3tb.Location = new System.Drawing.Point(190, 132);
            this.Box5Cell3tb.Name = "Box5Cell3tb";
            this.Box5Cell3tb.Size = new System.Drawing.Size(23, 23);
            this.Box5Cell3tb.TabIndex = 0;
            // 
            // Box5Cell2tb
            // 
            this.Box5Cell2tb.Location = new System.Drawing.Point(161, 132);
            this.Box5Cell2tb.Name = "Box5Cell2tb";
            this.Box5Cell2tb.Size = new System.Drawing.Size(23, 23);
            this.Box5Cell2tb.TabIndex = 0;
            // 
            // Box5Cell1tb
            // 
            this.Box5Cell1tb.Location = new System.Drawing.Point(132, 132);
            this.Box5Cell1tb.Name = "Box5Cell1tb";
            this.Box5Cell1tb.Size = new System.Drawing.Size(23, 23);
            this.Box5Cell1tb.TabIndex = 0;
            // 
            // Box6Cell1tb
            // 
            this.Box6Cell1tb.Location = new System.Drawing.Point(224, 132);
            this.Box6Cell1tb.Name = "Box6Cell1tb";
            this.Box6Cell1tb.Size = new System.Drawing.Size(23, 23);
            this.Box6Cell1tb.TabIndex = 0;
            // 
            // Box6Cell2tb
            // 
            this.Box6Cell2tb.Location = new System.Drawing.Point(253, 132);
            this.Box6Cell2tb.Name = "Box6Cell2tb";
            this.Box6Cell2tb.Size = new System.Drawing.Size(23, 23);
            this.Box6Cell2tb.TabIndex = 0;
            // 
            // Box6Cell3tb
            // 
            this.Box6Cell3tb.Location = new System.Drawing.Point(282, 132);
            this.Box6Cell3tb.Name = "Box6Cell3tb";
            this.Box6Cell3tb.Size = new System.Drawing.Size(23, 23);
            this.Box6Cell3tb.TabIndex = 0;
            // 
            // Box6Cell4tb
            // 
            this.Box6Cell4tb.Location = new System.Drawing.Point(224, 161);
            this.Box6Cell4tb.Name = "Box6Cell4tb";
            this.Box6Cell4tb.Size = new System.Drawing.Size(23, 23);
            this.Box6Cell4tb.TabIndex = 0;
            // 
            // Box6Cell5tb
            // 
            this.Box6Cell5tb.Location = new System.Drawing.Point(253, 161);
            this.Box6Cell5tb.Name = "Box6Cell5tb";
            this.Box6Cell5tb.Size = new System.Drawing.Size(23, 23);
            this.Box6Cell5tb.TabIndex = 0;
            // 
            // Box6Cell6tb
            // 
            this.Box6Cell6tb.Location = new System.Drawing.Point(282, 161);
            this.Box6Cell6tb.Name = "Box6Cell6tb";
            this.Box6Cell6tb.Size = new System.Drawing.Size(23, 23);
            this.Box6Cell6tb.TabIndex = 0;
            // 
            // Box6Cell7tb
            // 
            this.Box6Cell7tb.Location = new System.Drawing.Point(224, 190);
            this.Box6Cell7tb.Name = "Box6Cell7tb";
            this.Box6Cell7tb.Size = new System.Drawing.Size(23, 23);
            this.Box6Cell7tb.TabIndex = 0;
            // 
            // Box6Cell8tb
            // 
            this.Box6Cell8tb.Location = new System.Drawing.Point(253, 190);
            this.Box6Cell8tb.Name = "Box6Cell8tb";
            this.Box6Cell8tb.Size = new System.Drawing.Size(23, 23);
            this.Box6Cell8tb.TabIndex = 0;
            // 
            // Box5Cell4tb
            // 
            this.Box5Cell4tb.Location = new System.Drawing.Point(132, 161);
            this.Box5Cell4tb.Name = "Box5Cell4tb";
            this.Box5Cell4tb.Size = new System.Drawing.Size(23, 23);
            this.Box5Cell4tb.TabIndex = 0;
            // 
            // Box6Cell9tb
            // 
            this.Box6Cell9tb.Location = new System.Drawing.Point(282, 190);
            this.Box6Cell9tb.Name = "Box6Cell9tb";
            this.Box6Cell9tb.Size = new System.Drawing.Size(23, 23);
            this.Box6Cell9tb.TabIndex = 0;
            // 
            // Box7Cell1tb
            // 
            this.Box7Cell1tb.Location = new System.Drawing.Point(40, 224);
            this.Box7Cell1tb.Name = "Box7Cell1tb";
            this.Box7Cell1tb.Size = new System.Drawing.Size(23, 23);
            this.Box7Cell1tb.TabIndex = 0;
            // 
            // Box7Cell4tb
            // 
            this.Box7Cell4tb.Location = new System.Drawing.Point(40, 253);
            this.Box7Cell4tb.Name = "Box7Cell4tb";
            this.Box7Cell4tb.Size = new System.Drawing.Size(23, 23);
            this.Box7Cell4tb.TabIndex = 0;
            // 
            // Box7Cell5tb
            // 
            this.Box7Cell5tb.Location = new System.Drawing.Point(69, 253);
            this.Box7Cell5tb.Name = "Box7Cell5tb";
            this.Box7Cell5tb.Size = new System.Drawing.Size(23, 23);
            this.Box7Cell5tb.TabIndex = 0;
            // 
            // Box7Cell6tb
            // 
            this.Box7Cell6tb.Location = new System.Drawing.Point(98, 253);
            this.Box7Cell6tb.Name = "Box7Cell6tb";
            this.Box7Cell6tb.Size = new System.Drawing.Size(23, 23);
            this.Box7Cell6tb.TabIndex = 0;
            // 
            // Box7Cell7tb
            // 
            this.Box7Cell7tb.Location = new System.Drawing.Point(40, 282);
            this.Box7Cell7tb.Name = "Box7Cell7tb";
            this.Box7Cell7tb.Size = new System.Drawing.Size(23, 23);
            this.Box7Cell7tb.TabIndex = 0;
            // 
            // Box7Cell8tb
            // 
            this.Box7Cell8tb.Location = new System.Drawing.Point(69, 282);
            this.Box7Cell8tb.Name = "Box7Cell8tb";
            this.Box7Cell8tb.Size = new System.Drawing.Size(23, 23);
            this.Box7Cell8tb.TabIndex = 0;
            // 
            // Box7Cell9tb
            // 
            this.Box7Cell9tb.Location = new System.Drawing.Point(98, 282);
            this.Box7Cell9tb.Name = "Box7Cell9tb";
            this.Box7Cell9tb.Size = new System.Drawing.Size(23, 23);
            this.Box7Cell9tb.TabIndex = 0;
            // 
            // Box8Cell9tb
            // 
            this.Box8Cell9tb.Location = new System.Drawing.Point(190, 282);
            this.Box8Cell9tb.Name = "Box8Cell9tb";
            this.Box8Cell9tb.Size = new System.Drawing.Size(23, 23);
            this.Box8Cell9tb.TabIndex = 0;
            // 
            // Box8Cell8tb
            // 
            this.Box8Cell8tb.Location = new System.Drawing.Point(161, 282);
            this.Box8Cell8tb.Name = "Box8Cell8tb";
            this.Box8Cell8tb.Size = new System.Drawing.Size(23, 23);
            this.Box8Cell8tb.TabIndex = 0;
            // 
            // Box8Cell7tb
            // 
            this.Box8Cell7tb.Location = new System.Drawing.Point(132, 282);
            this.Box8Cell7tb.Name = "Box8Cell7tb";
            this.Box8Cell7tb.Size = new System.Drawing.Size(23, 23);
            this.Box8Cell7tb.TabIndex = 0;
            // 
            // Box8Cell6tb
            // 
            this.Box8Cell6tb.Location = new System.Drawing.Point(190, 253);
            this.Box8Cell6tb.Name = "Box8Cell6tb";
            this.Box8Cell6tb.Size = new System.Drawing.Size(23, 23);
            this.Box8Cell6tb.TabIndex = 0;
            // 
            // Box7Cell2tb
            // 
            this.Box7Cell2tb.Location = new System.Drawing.Point(69, 224);
            this.Box7Cell2tb.Name = "Box7Cell2tb";
            this.Box7Cell2tb.Size = new System.Drawing.Size(23, 23);
            this.Box7Cell2tb.TabIndex = 0;
            // 
            // Box7Cell3tb
            // 
            this.Box7Cell3tb.Location = new System.Drawing.Point(98, 224);
            this.Box7Cell3tb.Name = "Box7Cell3tb";
            this.Box7Cell3tb.Size = new System.Drawing.Size(23, 23);
            this.Box7Cell3tb.TabIndex = 0;
            // 
            // Box8Cell5tb
            // 
            this.Box8Cell5tb.Location = new System.Drawing.Point(161, 253);
            this.Box8Cell5tb.Name = "Box8Cell5tb";
            this.Box8Cell5tb.Size = new System.Drawing.Size(23, 23);
            this.Box8Cell5tb.TabIndex = 0;
            // 
            // Box8Cell2tb
            // 
            this.Box8Cell2tb.Location = new System.Drawing.Point(161, 224);
            this.Box8Cell2tb.Name = "Box8Cell2tb";
            this.Box8Cell2tb.Size = new System.Drawing.Size(23, 23);
            this.Box8Cell2tb.TabIndex = 0;
            // 
            // Box8Cell1tb
            // 
            this.Box8Cell1tb.Location = new System.Drawing.Point(132, 224);
            this.Box8Cell1tb.Name = "Box8Cell1tb";
            this.Box8Cell1tb.Size = new System.Drawing.Size(23, 23);
            this.Box8Cell1tb.TabIndex = 0;
            // 
            // Box9Cell1tb
            // 
            this.Box9Cell1tb.Location = new System.Drawing.Point(224, 224);
            this.Box9Cell1tb.Name = "Box9Cell1tb";
            this.Box9Cell1tb.Size = new System.Drawing.Size(23, 23);
            this.Box9Cell1tb.TabIndex = 0;
            // 
            // Box9Cell2tb
            // 
            this.Box9Cell2tb.Location = new System.Drawing.Point(253, 224);
            this.Box9Cell2tb.Name = "Box9Cell2tb";
            this.Box9Cell2tb.Size = new System.Drawing.Size(23, 23);
            this.Box9Cell2tb.TabIndex = 0;
            // 
            // Box9Cell3tb
            // 
            this.Box9Cell3tb.Location = new System.Drawing.Point(282, 224);
            this.Box9Cell3tb.Name = "Box9Cell3tb";
            this.Box9Cell3tb.Size = new System.Drawing.Size(23, 23);
            this.Box9Cell3tb.TabIndex = 0;
            // 
            // Box9Cell4tb
            // 
            this.Box9Cell4tb.Location = new System.Drawing.Point(224, 253);
            this.Box9Cell4tb.Name = "Box9Cell4tb";
            this.Box9Cell4tb.Size = new System.Drawing.Size(23, 23);
            this.Box9Cell4tb.TabIndex = 0;
            // 
            // Box9Cell5tb
            // 
            this.Box9Cell5tb.Location = new System.Drawing.Point(253, 253);
            this.Box9Cell5tb.Name = "Box9Cell5tb";
            this.Box9Cell5tb.Size = new System.Drawing.Size(23, 23);
            this.Box9Cell5tb.TabIndex = 0;
            // 
            // Box9Cell6tb
            // 
            this.Box9Cell6tb.Location = new System.Drawing.Point(282, 253);
            this.Box9Cell6tb.Name = "Box9Cell6tb";
            this.Box9Cell6tb.Size = new System.Drawing.Size(23, 23);
            this.Box9Cell6tb.TabIndex = 0;
            // 
            // Box9Cell7tb
            // 
            this.Box9Cell7tb.Location = new System.Drawing.Point(224, 282);
            this.Box9Cell7tb.Name = "Box9Cell7tb";
            this.Box9Cell7tb.Size = new System.Drawing.Size(23, 23);
            this.Box9Cell7tb.TabIndex = 0;
            // 
            // Box9Cell8tb
            // 
            this.Box9Cell8tb.Location = new System.Drawing.Point(253, 282);
            this.Box9Cell8tb.Name = "Box9Cell8tb";
            this.Box9Cell8tb.Size = new System.Drawing.Size(23, 23);
            this.Box9Cell8tb.TabIndex = 0;
            // 
            // Box8Cell4tb
            // 
            this.Box8Cell4tb.Location = new System.Drawing.Point(132, 253);
            this.Box8Cell4tb.Name = "Box8Cell4tb";
            this.Box8Cell4tb.Size = new System.Drawing.Size(23, 23);
            this.Box8Cell4tb.TabIndex = 0;
            // 
            // Box8Cell3tb
            // 
            this.Box8Cell3tb.Location = new System.Drawing.Point(190, 224);
            this.Box8Cell3tb.Name = "Box8Cell3tb";
            this.Box8Cell3tb.Size = new System.Drawing.Size(23, 23);
            this.Box8Cell3tb.TabIndex = 0;
            // 
            // Box9Cell9tb
            // 
            this.Box9Cell9tb.Location = new System.Drawing.Point(282, 282);
            this.Box9Cell9tb.Name = "Box9Cell9tb";
            this.Box9Cell9tb.Size = new System.Drawing.Size(23, 23);
            this.Box9Cell9tb.TabIndex = 0;
            // 
            // SolveBtn
            // 
            this.SolveBtn.Location = new System.Drawing.Point(309, 40);
            this.SolveBtn.Name = "SolveBtn";
            this.SolveBtn.Size = new System.Drawing.Size(153, 23);
            this.SolveBtn.TabIndex = 1;
            this.SolveBtn.Text = "Solve";
            this.SolveBtn.UseVisualStyleBackColor = true;
            this.SolveBtn.Click += new System.EventHandler(this.SolveBtn_Click);
            // 
            // debugLabel
            // 
            this.debugLabel.AutoSize = true;
            this.debugLabel.Location = new System.Drawing.Point(322, 68);
            this.debugLabel.Name = "debugLabel";
            this.debugLabel.Size = new System.Drawing.Size(0, 15);
            this.debugLabel.TabIndex = 2;
            // 
            // ClearBtn
            // 
            this.ClearBtn.Location = new System.Drawing.Point(309, 69);
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.Size = new System.Drawing.Size(153, 23);
            this.ClearBtn.TabIndex = 3;
            this.ClearBtn.Text = "Clear";
            this.ClearBtn.UseVisualStyleBackColor = true;
            this.ClearBtn.Click += new System.EventHandler(this.ClearBtn_Click);
            // 
            // ErrorLbl
            // 
            this.ErrorLbl.AutoSize = true;
            this.ErrorLbl.Location = new System.Drawing.Point(309, 106);
            this.ErrorLbl.Name = "ErrorLbl";
            this.ErrorLbl.Size = new System.Drawing.Size(0, 120);
            this.ErrorLbl.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 346);
            this.Controls.Add(this.ErrorLbl);
            this.Controls.Add(this.ClearBtn);
            this.Controls.Add(this.debugLabel);
            this.Controls.Add(this.SolveBtn);
            this.Controls.Add(this.Box9Cell9tb);
            this.Controls.Add(this.Box8Cell3tb);
            this.Controls.Add(this.Box8Cell4tb);
            this.Controls.Add(this.Box9Cell8tb);
            this.Controls.Add(this.Box9Cell7tb);
            this.Controls.Add(this.Box9Cell6tb);
            this.Controls.Add(this.Box9Cell5tb);
            this.Controls.Add(this.Box9Cell4tb);
            this.Controls.Add(this.Box9Cell3tb);
            this.Controls.Add(this.Box9Cell2tb);
            this.Controls.Add(this.Box9Cell1tb);
            this.Controls.Add(this.Box8Cell1tb);
            this.Controls.Add(this.Box8Cell2tb);
            this.Controls.Add(this.Box8Cell5tb);
            this.Controls.Add(this.Box7Cell3tb);
            this.Controls.Add(this.Box7Cell2tb);
            this.Controls.Add(this.Box8Cell6tb);
            this.Controls.Add(this.Box8Cell7tb);
            this.Controls.Add(this.Box8Cell8tb);
            this.Controls.Add(this.Box8Cell9tb);
            this.Controls.Add(this.Box7Cell9tb);
            this.Controls.Add(this.Box7Cell8tb);
            this.Controls.Add(this.Box7Cell7tb);
            this.Controls.Add(this.Box7Cell6tb);
            this.Controls.Add(this.Box7Cell5tb);
            this.Controls.Add(this.Box7Cell4tb);
            this.Controls.Add(this.Box7Cell1tb);
            this.Controls.Add(this.Box6Cell9tb);
            this.Controls.Add(this.Box5Cell4tb);
            this.Controls.Add(this.Box6Cell8tb);
            this.Controls.Add(this.Box6Cell7tb);
            this.Controls.Add(this.Box6Cell6tb);
            this.Controls.Add(this.Box6Cell5tb);
            this.Controls.Add(this.Box6Cell4tb);
            this.Controls.Add(this.Box6Cell3tb);
            this.Controls.Add(this.Box6Cell2tb);
            this.Controls.Add(this.Box6Cell1tb);
            this.Controls.Add(this.Box5Cell1tb);
            this.Controls.Add(this.Box5Cell2tb);
            this.Controls.Add(this.Box5Cell3tb);
            this.Controls.Add(this.Box5Cell5tb);
            this.Controls.Add(this.Box4Cell2tb);
            this.Controls.Add(this.Box5Cell6tb);
            this.Controls.Add(this.Box5Cell7tb);
            this.Controls.Add(this.Box5Cell8tb);
            this.Controls.Add(this.Box5Cell9tb);
            this.Controls.Add(this.Box4Cell9tb);
            this.Controls.Add(this.Box4Cell8tb);
            this.Controls.Add(this.Box4Cell7tb);
            this.Controls.Add(this.Box4Cell6tb);
            this.Controls.Add(this.Box4Cell5tb);
            this.Controls.Add(this.Box4Cell4tb);
            this.Controls.Add(this.Box4Cell3tb);
            this.Controls.Add(this.Box4Cell1tb);
            this.Controls.Add(this.Box3Cell9tb);
            this.Controls.Add(this.Box3Cell8tb);
            this.Controls.Add(this.Box3Cell7tb);
            this.Controls.Add(this.Box3Cell6tb);
            this.Controls.Add(this.Box3Cell5tb);
            this.Controls.Add(this.Box3Cell4tb);
            this.Controls.Add(this.Box3Cell3tb);
            this.Controls.Add(this.Box3Cell2tb);
            this.Controls.Add(this.Box3Cell1tb);
            this.Controls.Add(this.Box2Cell1tb);
            this.Controls.Add(this.Box2Cell2tb);
            this.Controls.Add(this.Box2Cell3tb);
            this.Controls.Add(this.Box2Cell4tb);
            this.Controls.Add(this.Box2Cell5tb);
            this.Controls.Add(this.Box2Cell6tb);
            this.Controls.Add(this.Box2Cell7tb);
            this.Controls.Add(this.Box2Cell8tb);
            this.Controls.Add(this.Box2Cell9tb);
            this.Controls.Add(this.Box1Cell9tb);
            this.Controls.Add(this.Box1Cell8tb);
            this.Controls.Add(this.Box1Cell7tb);
            this.Controls.Add(this.Box1Cell6tb);
            this.Controls.Add(this.Box1Cell5tb);
            this.Controls.Add(this.Box1Cell4tb);
            this.Controls.Add(this.Box1Cell3tb);
            this.Controls.Add(this.Box1Cell2tb);
            this.Controls.Add(this.Box1Cell1tb);
            this.Name = "Form1";
            this.Text = "Sudoku Solver";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Box1Cell1tb;
        private System.Windows.Forms.TextBox Box1Cell2tb;
        private System.Windows.Forms.TextBox Box1Cell3tb;
        private System.Windows.Forms.TextBox Box1Cell4tb;
        private System.Windows.Forms.TextBox Box1Cell5tb;
        private System.Windows.Forms.TextBox Box1Cell6tb;
        private System.Windows.Forms.TextBox Box1Cell7tb;
        private System.Windows.Forms.TextBox Box1Cell8tb;
        private System.Windows.Forms.TextBox Box1Cell9tb;
        private System.Windows.Forms.TextBox Box2Cell9tb;
        private System.Windows.Forms.TextBox Box2Cell8tb;
        private System.Windows.Forms.TextBox Box2Cell7tb;
        private System.Windows.Forms.TextBox Box2Cell6tb;
        private System.Windows.Forms.TextBox Box2Cell5tb;
        private System.Windows.Forms.TextBox Box2Cell4tb;
        private System.Windows.Forms.TextBox Box2Cell3tb;
        private System.Windows.Forms.TextBox Box2Cell2tb;
        private System.Windows.Forms.TextBox Box2Cell1tb;
        private System.Windows.Forms.TextBox Box3Cell1tb;
        private System.Windows.Forms.TextBox Box3Cell2tb;
        private System.Windows.Forms.TextBox Box3Cell3tb;
        private System.Windows.Forms.TextBox Box3Cell4tb;
        private System.Windows.Forms.TextBox Box3Cell5tb;
        private System.Windows.Forms.TextBox Box3Cell6tb;
        private System.Windows.Forms.TextBox Box3Cell7tb;
        private System.Windows.Forms.TextBox Box3Cell8tb;
        private System.Windows.Forms.TextBox Box3Cell9tb;
        private System.Windows.Forms.TextBox Box4Cell1tb;
        private System.Windows.Forms.TextBox Box4Cell3tb;
        private System.Windows.Forms.TextBox Box4Cell4tb;
        private System.Windows.Forms.TextBox Box4Cell5tb;
        private System.Windows.Forms.TextBox Box4Cell6tb;
        private System.Windows.Forms.TextBox Box4Cell7tb;
        private System.Windows.Forms.TextBox Box4Cell8tb;
        private System.Windows.Forms.TextBox Box4Cell9tb;
        private System.Windows.Forms.TextBox Box5Cell9tb;
        private System.Windows.Forms.TextBox Box5Cell8tb;
        private System.Windows.Forms.TextBox Box5Cell7tb;
        private System.Windows.Forms.TextBox Box5Cell6tb;
        private System.Windows.Forms.TextBox Box4Cell2tb;
        private System.Windows.Forms.TextBox Box5Cell5tb;
        private System.Windows.Forms.TextBox Box5Cell3tb;
        private System.Windows.Forms.TextBox Box5Cell2tb;
        private System.Windows.Forms.TextBox Box5Cell1tb;
        private System.Windows.Forms.TextBox Box6Cell1tb;
        private System.Windows.Forms.TextBox Box6Cell2tb;
        private System.Windows.Forms.TextBox Box6Cell3tb;
        private System.Windows.Forms.TextBox Box6Cell4tb;
        private System.Windows.Forms.TextBox Box6Cell5tb;
        private System.Windows.Forms.TextBox Box6Cell6tb;
        private System.Windows.Forms.TextBox Box6Cell7tb;
        private System.Windows.Forms.TextBox Box6Cell8tb;
        private System.Windows.Forms.TextBox Box5Cell4tb;
        private System.Windows.Forms.TextBox Box6Cell9tb;
        private System.Windows.Forms.TextBox Box7Cell1tb;
        private System.Windows.Forms.TextBox Box7Cell4tb;
        private System.Windows.Forms.TextBox Box7Cell5tb;
        private System.Windows.Forms.TextBox Box7Cell6tb;
        private System.Windows.Forms.TextBox Box7Cell7tb;
        private System.Windows.Forms.TextBox Box7Cell8tb;
        private System.Windows.Forms.TextBox Box7Cell9tb;
        private System.Windows.Forms.TextBox Box8Cell9tb;
        private System.Windows.Forms.TextBox Box8Cell8tb;
        private System.Windows.Forms.TextBox Box8Cell7tb;
        private System.Windows.Forms.TextBox Box8Cell6tb;
        private System.Windows.Forms.TextBox Box7Cell2tb;
        private System.Windows.Forms.TextBox Box7Cell3tb;
        private System.Windows.Forms.TextBox Box8Cell5tb;
        private System.Windows.Forms.TextBox Box8Cell2tb;
        private System.Windows.Forms.TextBox Box8Cell1tb;
        private System.Windows.Forms.TextBox Box9Cell1tb;
        private System.Windows.Forms.TextBox Box9Cell2tb;
        private System.Windows.Forms.TextBox Box9Cell3tb;
        private System.Windows.Forms.TextBox Box9Cell4tb;
        private System.Windows.Forms.TextBox Box9Cell5tb;
        private System.Windows.Forms.TextBox Box9Cell6tb;
        private System.Windows.Forms.TextBox Box9Cell7tb;
        private System.Windows.Forms.TextBox Box9Cell8tb;
        private System.Windows.Forms.TextBox Box8Cell4tb;
        private System.Windows.Forms.TextBox Box8Cell3tb;
        private System.Windows.Forms.TextBox Box9Cell9tb;
        private System.Windows.Forms.Button SolveBtn;
        private System.Windows.Forms.Label debugLabel;
        private System.Windows.Forms.Button ClearBtn;
        private System.Windows.Forms.Label ErrorLbl;
    }
}

